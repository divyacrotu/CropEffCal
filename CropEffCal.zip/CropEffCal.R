library(shiny)
library(readxl)
library(dplyr)
library(Benchmarking)
library(DT)
library(bslib)
library(shinybusy)
library(ggplot2)
library(plotly)
options(shiny.maxRequestSize = 50 * 1024^2)
ui <- navbarPage(
  title = "DEA Efficiency App",
  theme = bs_theme(bootswatch = "minty", version = 5),
  tabPanel("Single State DEA",
           fluidPage(
             add_busy_spinner(spin = "dots", position = "top-right"),
             sidebarLayout(
               sidebarPanel(
                 fileInput("file_upload", "Upload Excel File", accept = ".xlsx"),
                 uiOutput("state_selector"),
                 uiOutput("crop_selector"),
                 uiOutput("input_selector"),
                 uiOutput("output_selector"),
                 selectInput("level", "Aggregation Level:", choices = c("Farmer Level", "Tehsil Level", "Zone Level")),
                 radioButtons("orientation", "Orientation:", choices = c("Input", "Output"), inline = TRUE),
                 radioButtons("rts", "Returns to Scale:", choices = c("CRS", "VRS"), inline = TRUE),
                 actionButton("run_dea", "Run DEA"),
                 downloadButton("download_single", "Download Table")
               ),
               mainPanel(
                 h4("Average DEA Efficiency Scores"),
                 DTOutput("eff_output"),
                 plotlyOutput("eff_plot_single")
               )
             )
           )
  ),
  tabPanel("Compare States",
           sidebarLayout(
             sidebarPanel(
               fileInput("statewise_file", "Upload Excel File", accept = ".xlsx"),
               uiOutput("statewise_crop_selector"),
               uiOutput("statewise_state_selector"),
               uiOutput("statewise_input_selector"),
               uiOutput("statewise_output_selector"),
               radioButtons("orientation_statewise", "Orientation:", choices = c("Input", "Output"), inline = TRUE),
               radioButtons("rts_statewise", "Returns to Scale:", choices = c("CRS", "VRS"), inline = TRUE),
               actionButton("compare_statewise", "Compare States"),
               downloadButton("download_statewise", "Download Table")
             ),
             mainPanel(
               h4("State-wise Comparison for Selected Crop"),
               DTOutput("statewise_output"),
               plotlyOutput("statewise_plot")
             )
           )
  ),
  tabPanel("Compare Crops",
           sidebarLayout(
             sidebarPanel(
               fileInput("cropwise_file", "Upload Excel File", accept = ".xlsx"),
               uiOutput("cropwise_state_selector"),
               uiOutput("cropwise_crop_selector"),
               uiOutput("cropwise_input_selector"),
               uiOutput("cropwise_output_selector"),
               radioButtons("orientation_cropwise", "Orientation:", choices = c("Input", "Output"), inline = TRUE),
               radioButtons("rts_cropwise", "Returns to Scale:", choices = c("CRS", "VRS"), inline = TRUE),
               actionButton("compare_cropwise", "Compare Crops"),
               downloadButton("download_cropwise", "Download Table")
             ),
             mainPanel(
               h4("Crop-wise Comparison for Selected State"),
               DTOutput("cropwise_output"),
               plotlyOutput("cropwise_plot")
             )
           )
  )
)

server <- function(input, output, session) {
  
  sheet_names <- reactiveVal()
  uploaded_data <- reactiveVal()
  statewise_data <- reactiveVal()
  cropwise_data <- reactiveVal()
  statewise_result <- reactiveVal()
  cropwise_result <- reactiveVal()
  single_result <- reactiveVal()
  
  read_and_clean_excel <- function(file_path) {
    sheets <- excel_sheets(file_path)
    df_list <- lapply(sheets, function(sheet) {
      df <- read_excel(file_path, sheet = sheet, skip = 2)
      df <- setNames(df, make.names(names(df), unique = TRUE))
      df$State <- sheet
      mutate(df, across(everything(), as.character))
    })
    bind_rows(df_list)
  }
  
  observeEvent(input$file_upload, {
    req(input$file_upload)
    sheets <- excel_sheets(input$file_upload$datapath)
    sheet_names(sheets)
    output$state_selector <- renderUI({ selectInput("state", "Select State:", choices = sheets) })
  })
  
  observeEvent(input$state, {
    req(input$file_upload, input$state)
    df <- read_excel(input$file_upload$datapath, sheet = input$state, skip = 2)
    uploaded_data(df)
    if (!"Crop" %in% names(df)) return()
    output$crop_selector <- renderUI({ selectInput("crop", "Select Crop:", choices = unique(df$Crop)) })
    output$input_selector <- renderUI({ selectInput("inputs", "Select Input Variables:", choices = names(df), multiple = TRUE) })
    output$output_selector <- renderUI({ selectInput("outputs", "Select Output Variables:", choices = names(df), multiple = TRUE) })
  })
  
  observeEvent(input$run_dea, {
    req(uploaded_data(), input$crop, input$inputs, input$outputs)
    show_modal_spinner(text = "Running DEA...")
    df_crop <- uploaded_data() %>% filter(Crop == input$crop)
    df_crop <- df_crop %>% mutate(Identity = case_when(
      input$level == "Farmer Level" ~ paste0("Z", `Zone No.`, "_T", `Tehsil No.`, "_C", `Cultivator No.`),
      input$level == "Tehsil Level" ~ paste0("Z", `Zone No.`, "_T", `Tehsil No.`),
      input$level == "Zone Level" ~ paste0("Z", `Zone No.`)
    ))
    input_df <- df_crop %>% select(all_of(input$inputs)) %>% mutate_all(as.numeric)
    output_df <- df_crop %>% select(all_of(input$outputs)) %>% mutate_all(as.numeric)
    clean_data <- bind_cols(input_df, output_df) %>% mutate(row_id = row_number()) %>%
      filter(if_all(all_of(input$inputs), ~ !is.na(.) & . > 0)) %>%
      filter(if_all(all_of(input$outputs), ~ !is.na(.) & . >= 0))
    if (nrow(clean_data) == 0) return()
    valid_rows <- clean_data$row_id
    df_crop <- df_crop[valid_rows, ]
    inputs <- input_df[valid_rows, ] %>% as.matrix()
    outputs <- output_df[valid_rows, ] %>% as.matrix()
    orientation_val <- ifelse(input$orientation == "Input", "in", "out")
    rts_val <- tolower(input$rts)
    dea_result <- Benchmarking::dea(X = inputs, Y = outputs, RTS = rts_val, ORIENTATION = orientation_val)
    df_crop$Efficiency <- round(as.numeric(dea_result$eff), 4)
    agg_eff <- df_crop %>% group_by(Identity) %>% summarise(Average_Efficiency = mean(Efficiency), .groups = "drop")
    single_result(agg_eff)
    output$eff_output <- renderDT({ datatable(agg_eff) })
    output$eff_plot_single <- renderPlotly({
      ggplotly(ggplot(agg_eff, aes(x = reorder(Identity, Average_Efficiency), y = Average_Efficiency)) +
                 geom_col(fill = "steelblue") +
                 coord_flip() +
                 labs(title = "DEA Efficiency by Identity", x = "Identity", y = "Average Efficiency") +
                 theme_minimal())
    })
    remove_modal_spinner()
  })
  
  output$download_single <- downloadHandler(
    filename = function() { "single_state_efficiency.csv" },
    content = function(file) {
      write.csv(single_result(), file, row.names = FALSE)
    }
  )
  
  observeEvent(input$statewise_file, {
    req(input$statewise_file)
    combined_df <- read_and_clean_excel(input$statewise_file$datapath)
    statewise_data(combined_df)
  })
  
  observeEvent(input$cropwise_file, {
    req(input$cropwise_file)
    combined_df <- read_and_clean_excel(input$cropwise_file$datapath)
    cropwise_data(combined_df)
  })
  
  output$statewise_crop_selector <- renderUI({
    req(statewise_data())
    selectInput("selected_crop_statewise", "Select Crop:", choices = unique(statewise_data()$Crop))
  })
  
  output$statewise_state_selector <- renderUI({
    req(statewise_data())
    selectInput("selected_states", "Select States:", choices = unique(statewise_data()$State), multiple = TRUE)
  })
  
  output$statewise_input_selector <- renderUI({
    req(statewise_data())
    selectInput("statewise_inputs", "Select Input Variables:", choices = names(statewise_data()), multiple = TRUE)
  })
  
  output$statewise_output_selector <- renderUI({
    req(statewise_data())
    selectInput("statewise_outputs", "Select Output Variables:", choices = names(statewise_data()), multiple = TRUE)
  })
  
  output$cropwise_state_selector <- renderUI({
    req(cropwise_data())
    selectInput("selected_state_cropwise", "Select State:", choices = unique(cropwise_data()$State))
  })
  
  output$cropwise_crop_selector <- renderUI({
    req(cropwise_data())
    selectInput("selected_crops", "Select Crops:", choices = unique(cropwise_data()$Crop), multiple = TRUE)
  })
  
  output$cropwise_input_selector <- renderUI({
    req(cropwise_data())
    selectInput("cropwise_inputs", "Select Input Variables:", choices = names(cropwise_data()), multiple = TRUE)
  })
  
  output$cropwise_output_selector <- renderUI({
    req(cropwise_data())
    selectInput("cropwise_outputs", "Select Output Variables:", choices = names(cropwise_data()), multiple = TRUE)
  })
  
  observeEvent(input$compare_statewise, {
    req(statewise_data(), input$selected_crop_statewise, input$selected_states, input$statewise_inputs, input$statewise_outputs)
    df <- statewise_data() %>% filter(Crop == input$selected_crop_statewise, State %in% input$selected_states)
    df$Identity <- df$State
    inputs <- df %>% select(all_of(input$statewise_inputs)) %>% mutate_all(as.numeric)
    outputs <- df %>% select(all_of(input$statewise_outputs)) %>% mutate_all(as.numeric)
    dea_result <- Benchmarking::dea(X = as.matrix(inputs), Y = as.matrix(outputs), RTS = tolower(input$rts_statewise), ORIENTATION = ifelse(input$orientation_statewise == "Input", "in", "out"))
    df$Efficiency <- as.numeric(dea_result$eff)
    summary_df <- df %>% group_by(State) %>% summarise(Average_Efficiency = mean(Efficiency), .groups = "drop")
    statewise_result(summary_df)
    output$statewise_output <- renderDT({ datatable(summary_df) })
    output$statewise_plot <- renderPlotly({
      ggplotly(ggplot(summary_df, aes(x = reorder(State, Average_Efficiency), y = Average_Efficiency)) +
                 geom_col(fill = "darkgreen") +
                 coord_flip() +
                 labs(title = "State-wise Average DEA Efficiency", x = "State", y = "Efficiency") +
                 theme_minimal())
    })
  })
  
  output$download_statewise <- downloadHandler(
    filename = function() { "statewise_comparison.csv" },
    content = function(file) {
      write.csv(statewise_result(), file, row.names = FALSE)
    }
  )
  
  observeEvent(input$compare_cropwise, {
    req(cropwise_data(), input$selected_state_cropwise, input$selected_crops, input$cropwise_inputs, input$cropwise_outputs)
    df <- cropwise_data() %>% filter(State == input$selected_state_cropwise, Crop %in% input$selected_crops)
    df$Identity <- df$Crop
    inputs <- df %>% select(all_of(input$cropwise_inputs)) %>% mutate_all(as.numeric)
    outputs <- df %>% select(all_of(input$cropwise_outputs)) %>% mutate_all(as.numeric)
    dea_result <- Benchmarking::dea(X = as.matrix(inputs), Y = as.matrix(outputs), RTS = tolower(input$rts_cropwise), ORIENTATION = ifelse(input$orientation_cropwise == "Input", "in", "out"))
    df$Efficiency <- as.numeric(dea_result$eff)
    summary_df <- df %>% group_by(Crop) %>% summarise(Average_Efficiency = mean(Efficiency), .groups = "drop")
    cropwise_result(summary_df)
    output$cropwise_output <- renderDT({ datatable(summary_df) })
    output$cropwise_plot <- renderPlotly({
      ggplotly(ggplot(summary_df, aes(x = reorder(Crop, Average_Efficiency), y = Average_Efficiency)) +
                 geom_col(fill = "tomato") +
                 coord_flip() +
                 labs(title = "Crop-wise Average DEA Efficiency", x = "Crop", y = "Efficiency") +
                 theme_minimal())
    })
  })
  
  output$download_cropwise <- downloadHandler(
    filename = function() { "cropwise_comparison.csv" },
    content = function(file) {
      write.csv(cropwise_result(), file, row.names = FALSE)
    }
  )
}

shinyApp(ui, server)
